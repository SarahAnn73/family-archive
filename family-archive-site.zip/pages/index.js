import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QRCodeSVG } from "qrcode.react";

export default function FamilyArchiveWebsite() {
  return (
    <div className="min-h-screen bg-black text-white p-6 flex flex-col items-center justify-center space-y-8">
      <h1 className="text-4xl font-bold text-center">My Family Helped Build This</h1>
      <p className="text-lg max-w-xl text-center">
        An Archive of Inheritance, Enslavement, and the Legacy of Power.
        Created by Sarah.
      </p>

      <Card className="bg-white text-black w-full max-w-2xl p-6 rounded-2xl shadow-xl">
        <CardContent className="space-y-4">
          <h2 className="text-2xl font-bold">Family Timeline</h2>
          <p>
            Elizabeth Freeman (1673) -> Benjamin Rainey (1811) -> Sarah “Sally” Woods (1830) ->
            Margaret Julia Raney (1939) -> Hayward Newton Smith (1961) ->
            Robert Smith (1961) -> Jo Ann Williams (1949) -> Rhonda Williams (1967) -> Sarah
          </p>

          <h2 className="text-2xl font-bold">Names of the Enslaved</h2>
          <ul className="list-disc list-inside">
            <li>Rose — older woman</li>
            <li>Mood — man (no age listed)</li>
            <li>Ben — young boy</li>
            <li>Mary — enslaved, marked “5”</li>
            <li>Kizzie — explicitly named</li>
            <li>Luce, Caleb, Abram — listed in wills</li>
          </ul>

          <h2 className="text-2xl font-bold">Primary Sources</h2>
          <ul className="list-disc list-inside">
            <li>Benjamin Rainey’s Will (1811)</li>
            <li>Probate records of enslaved people</li>
            <li>Land settlements and guardianship records</li>
            <li>Cotton mill empire documents</li>
          </ul>

          <h2 className="text-2xl font-bold">Migration Path</h2>
          <p>
            New Jersey -> Virginia -> Kentucky -> Tennessee -> North Carolina -> South Carolina -> Missouri -> Pennsylvania
          </p>

          <h2 className="text-2xl font-bold">Statement</h2>
          <p>
            I didn’t build this system. But I benefited from it. So I’m breaking the silence it was built on.
            They took land. They bought people. They called it faith. They called it law.
            In their wills, children were listed next to cows.
            In their churches, they preached obedience while holding whips.
            In their ledgers, the enslaved are numbered and named.
          </p>
        </CardContent>
      </Card>

      <div className="text-center space-y-2">
        <h2 className="text-xl font-bold">Scan to Access Full Archive</h2>
        <QRCodeSVG value="https://example.com/family-archive" size={160} bgColor="#000" fgColor="#fff" />
      </div>

      <Button className="mt-6 bg-white text-black hover:bg-gray-200 text-lg font-bold px-6 py-3 rounded-xl">
        Download the Zine (PDF)
      </Button>
    </div>
  );
}
